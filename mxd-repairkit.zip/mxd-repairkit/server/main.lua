local QBCore = exports['qb-core']:GetCoreObject()

-- Register Usable Item
QBCore.Functions.CreateUseableItem(Config.ItemName, function(source, item)
    local Player = QBCore.Functions.GetPlayer(source)
    if not Player then return end

    -- Trigger client side event to start repair process
    -- We don't remove item here, we wait for success
    TriggerClientEvent('mxd-repairkit:client:UseKit', source, item)
end)

-- Event to remove item after successful repair
RegisterNetEvent('mxd-repairkit:server:ConsumeItem', function()
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)

    if not Player then return end

    -- Security check: could ideally check distance/time tokens, but for now we trust the client flow
    -- Remove the item
    if Config.ConsumeItem then
        Player.Functions.RemoveItem(Config.ItemName, 1)
        TriggerClientEvent('inventory:client:ItemBox', src, QBCore.Shared.Items[Config.ItemName], "remove")
    end
end)
