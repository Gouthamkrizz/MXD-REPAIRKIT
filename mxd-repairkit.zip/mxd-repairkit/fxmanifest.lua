fx_version 'cerulean'
game 'gta5'

author 'mxd'
description 'Vehicle Repair Kit for QBCore'
version '1.0.0'

shared_scripts {
    '@qb-core/shared/locale.lua',
    'locales/en.lua', -- Placeholder if needed, but we typically just use Config for simple strings or hardcode if not specified. I'll stick to config for text.
    'config.lua'
}

server_scripts {
    '@oxmysql/lib/MySQL.lua', -- Just in case, though likely not needed for this simple script
    'server/main.lua'
}

client_scripts {
    'client/main.lua'
}

lua54 'yes'
