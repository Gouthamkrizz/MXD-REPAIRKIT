Config = {}

Config.Debug = false

-- Repair Settings
Config.RepairDistance = 3.0                 -- How close the player needs to be to the vehicle
Config.RepairDuration = 10000               -- Time in ms to repair the vehicle (10 seconds)
Config.RepairLabel = "Repairing Vehicle..." -- Text displayed on the progress bar

-- Animation Settings
Config.AnimDict = "mini@repair"
Config.AnimName = "fixing_a_ped"

-- Repair Values
Config.TargetEngineHealth = 1000.0 -- Engine health to set (1000 is full)
Config.TargetBodyHealth = 1000.0   -- Body health to set (1000 is full)
Config.FixTires = true             -- Should it fix burst tires?
Config.FixDeformation = true       -- Should it visual deformation?

-- Item Name (Must match item in ox_inventory/qb-core shared)
Config.ItemName = "repairkit"

-- Consumable?
Config.ConsumeItem = false

-- Job Requirement (nil to allow everyone)
-- Config.Job = "mechanic"
