local QBCore = exports['qb-core']:GetCoreObject()

-- Helper function to get vehicle in front of player
local function GetVehicleInFront()
    local ped = PlayerPedId()
    local pos = GetEntityCoords(ped)
    local offset = GetOffsetFromEntityInWorldCoords(ped, 0.0, 5.0, 0.0)
    local shapeTest = StartShapeTestCapsule(pos.x, pos.y, pos.z, offset.x, offset.y, offset.z, 2.0, 10, ped, 7)
    local _, hit, _, _, entityHit = GetShapeTestResult(shapeTest)

    if hit == 1 and IsEntityAVehicle(entityHit) then
        return entityHit
    end
    return nil
end

-- Clean up any tire bursts
local function FixTires(vehicle)
    for i = 0, 5 do
        SetVehicleTyreFixed(vehicle, i)
    end
end

RegisterNetEvent('mxd-repairkit:client:UseKit', function(item)
    local ped = PlayerPedId()
    local coords = GetEntityCoords(ped)

    -- Check if inside vehicle
    if IsPedInAnyVehicle(ped, false) then
        QBCore.Functions.Notify("You cannot do this from inside a vehicle!", "error")
        return
    end

    -- Find nearest vehicle in front
    local vehicle = GetVehicleInFront()

    -- Fallback to closest vehicle if direction check fails but one is very close
    if not vehicle then
        vehicle = QBCore.Functions.GetClosestVehicle(coords)
    end

    if not vehicle or vehicle == 0 then
        QBCore.Functions.Notify("No vehicle nearby!", "error")
        return
    end

    -- Distance check
    local vehCoords = GetEntityCoords(vehicle)
    local dist = #(coords - vehCoords)
    if dist > Config.RepairDistance then
        QBCore.Functions.Notify("You are too far from the vehicle!", "error")
        return
    end

    -- Check if vehicle is actually damaged (Optional, but good UX.
    -- Request just says "Repair... Engine health to 1000", implied it always runs)

    -- Start Repair Sequence
    QBCore.Functions.Progressbar("repair_vehicle", Config.RepairLabel, Config.RepairDuration, false, true, {
        disableMovement = true,
        disableCarMovement = true,
        disableMouse = false,
        disableCombat = true,
    }, {
        animDict = Config.AnimDict,
        anim = Config.AnimName,
        flags = 16,       -- Loop
    }, {}, {}, function() -- Done
        -- Validate distance again? Usually not strictly necessary if movement disabled, but good practice.
        if #(GetEntityCoords(ped) - GetEntityCoords(vehicle)) > Config.RepairDistance + 2.0 then
            QBCore.Functions.Notify("Canceled.. Too far!", "error")
            return
        end

        local engineHealth = Config.TargetEngineHealth
        local bodyHealth = Config.TargetBodyHealth

        -- Set Health
        SetVehicleEngineHealth(vehicle, engineHealth)
        SetVehicleBodyHealth(vehicle, bodyHealth)

        if Config.FixDeformation then
            SetVehicleDeformationFixed(vehicle)
        end

        if Config.FixTires then
            FixTires(vehicle)
        end

        -- Often needed to sync explicit damage removal
        SetVehicleFixed(vehicle)
        -- Re-apply health values after SetVehicleFixed because SetVehicleFixed fully heals everything
        -- (SetVehicleFixed heals to max, so if we wanted partial repair we'd need to re-set.
        -- But prompt says "Engine health to 1000", "Body health to 1000", so full repair is implied.
        -- However, SetVehicleFixed handles deformation/dirt too.
        -- Just to be safe and specific as per config:
        SetVehicleEngineHealth(vehicle, engineHealth)
        SetVehicleBodyHealth(vehicle, bodyHealth)

        QBCore.Functions.Notify("Vehicle Repaired!", "success")

        -- Trigger Server to Consume Item
        TriggerServerEvent('mxd-repairkit:server:ConsumeItem')
    end, function() -- Cancel
        QBCore.Functions.Notify("Repair Canceled!", "error")
        -- Stop animation handled by progressbar usually, but implicit via ClearPedTasks
        ClearPedTasks(ped)
    end)
end)
